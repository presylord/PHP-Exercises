<?php

class Signup_model extends Dbh
{
    protected function checkUser($uid, $email)
    {
        $sql = "SELECT users_uid FROM users where users_uid = ? OR users_email = ?";
        $stmt = $this->connect()->prepare($sql);

        if (!$stmt->execute([$uid, $email])) {
            $stmt = null;
            header("location: ../index.php?error=stmtfailed");
            exit();
        }

        if ($stmt->rowCount() > 0) {
            $resultCheck = false;
        } else {
            $resultCheck = false;
        }
        return $resultCheck;
    }
}
